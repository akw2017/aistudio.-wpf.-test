﻿namespace Settings.UserProfile
{
	using System;

	internal class LocalizabilityAttribute : Attribute
	{
	}
}