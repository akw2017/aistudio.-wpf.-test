﻿namespace Settings.Interfaces
{
	using SettingsModel.Interfaces;

	public interface IOptionsPanel
	{
		IEngine Options { get; }
	}
}