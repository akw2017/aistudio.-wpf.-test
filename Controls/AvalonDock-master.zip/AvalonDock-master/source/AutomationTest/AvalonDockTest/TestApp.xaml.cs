﻿namespace AvalonDockTest
{
    using System.Windows;

    public partial class TestApp : Application
    {
        public TestApp()
        {
        }
    }
}
