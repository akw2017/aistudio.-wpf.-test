﻿using System.Windows;

namespace AvalonDockTest.Views
{
	/// <summary>
	/// Interaction logic for LayoutAnchorableFloatingWindowControlTestWindow.xaml
	/// </summary>
	public partial class LayoutAnchorableFloatingWindowControlTestWindow : Window
	{
		public LayoutAnchorableFloatingWindowControlTestWindow()
		{
			InitializeComponent();
		}
	}
}
