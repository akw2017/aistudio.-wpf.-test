using System.Runtime.InteropServices;

[assembly: ComVisible(false)]

[assembly: Guid("fe4e16a2-876a-4356-9974-8a89c50b2a5a")]
