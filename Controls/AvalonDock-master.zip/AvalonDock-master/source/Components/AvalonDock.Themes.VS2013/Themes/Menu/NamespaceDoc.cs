namespace AvalonDock.Themes.Themes.Menu
{
	/// <summary>This namespace defines the themed menu specific items for this theme in AvalonDock.</summary>
	[System.Runtime.CompilerServices.CompilerGenerated]
	internal class NamespaceDoc
	{
	}
}
