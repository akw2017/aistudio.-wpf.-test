namespace AvalonDock.Themes
{
	/// <summary>This library defines the VS2013 theme for AvalonDock.</summary>
	[System.Runtime.CompilerServices.CompilerGenerated]
	internal class NamespaceDoc
	{
	}
}
