namespace AvalonDock.Themes
{
	/// <summary>This library defines the Aero theme for AvalonDock.</summary>
	[System.Runtime.CompilerServices.CompilerGenerated]
	internal class NamespaceDoc
	{
	}
}
