namespace AvalonDock.Controls.Shell.Standard
{
	/// <summary>This namespace contains the interaction and definitions to Win32 core system and structures.</summary>
	[System.Runtime.CompilerServices.CompilerGenerated]
	internal class NamespaceDoc
	{
	}
}