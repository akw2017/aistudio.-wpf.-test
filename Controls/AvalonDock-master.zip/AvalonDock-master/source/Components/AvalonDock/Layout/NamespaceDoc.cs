namespace AvalonDock.Layout
{
	/// <summary>This namespace has the definition and implementation for the layout tree.</summary>
	[System.Runtime.CompilerServices.CompilerGenerated]
	internal class NamespaceDoc
	{
	}
}