namespace AvalonDock.Commands
{
	/// <summary>This namespace contains <see cref="System.Windows.Input.ICommand"/> implementations.</summary>
	[System.Runtime.CompilerServices.CompilerGenerated]
	internal class NamespaceDoc
	{
	}
}