namespace AvalonDock.Themes
{
	/// <summary>This namespace holds the base classes and implementations to support custom theme's.</summary>
	[System.Runtime.CompilerServices.CompilerGenerated]
	internal class NamespaceDoc
	{
	}
}
