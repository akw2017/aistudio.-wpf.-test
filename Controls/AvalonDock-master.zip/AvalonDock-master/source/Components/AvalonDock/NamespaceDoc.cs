namespace AvalonDock
{
	/// <summary>
	/// This is the entry for the AvalonDock library. This is a fork of the original library created by Xceed.
	/// This fork aims more on an open source collaboration.
	/// </summary>
	[System.Runtime.CompilerServices.CompilerGenerated]
	internal class NamespaceDoc
	{
	}
}
