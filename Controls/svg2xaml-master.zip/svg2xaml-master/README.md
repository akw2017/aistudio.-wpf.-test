svg2xaml
========

fork of https://svg2xaml.codeplex.com
